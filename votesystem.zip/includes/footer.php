<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2025 <a href="">Sunny Sharma & Ajinkya Dewan</a></strong>
    </div>
    <!-- /.container -->
</footer>